// js/users/validar.js
firebase.auth().onAuthStateChanged((user) => {
  if (!user) {
    // Si no hay usuario logueado, redirige al login
    window.location.href = "login.html";
  }
});
